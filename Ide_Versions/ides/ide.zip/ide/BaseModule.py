"""
BaseModule
 - version 1.1 Circumcision version
 - by *-chara-*#7034
"""

import sys
import os
import json


def __cls_or_clear_platform():
    if sys.platform == 'win32':
        return "cls"
    else:
        return "clear"


mcls = lambda: os.system(__cls_or_clear_platform())
mplatform = lambda: sys.platform
misfile = lambda path: os.path.isfile(path)
misdir = lambda path: os.path.isdir(path)
mkdir = lambda path: os.mkdir(path)
mexists = lambda path: os.path.exists(path)
mwhatinfile = lambda path: os.listdir(path)
msystem = lambda command: os.system(command)


def load_json(derictory, Name, Name2=None):
    try:
        with open(derictory, encoding="utf-8") as config_file:
            data = json.load(config_file)
            config_file.close()
        Num = data[str(Name)]
        if Name2 != None:
            Num2 = data[str(Name2)]
        else:
            return "!", Num, None
        return "!", Num, Num2
    except:
        return None, None, None


def input_json(derictory, Data):
    with open(derictory, 'w', encoding="UTF-8") as file:
        json.dump(Data, file, indent=2, ensure_ascii=False)


def loadall_json(derictory) -> dict:
    if misfile(derictory):
        with open(derictory, encoding="utf-8") as config_file:
            data = json.load(config_file)
        return data
    else:
        return None
