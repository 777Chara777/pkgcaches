import sys
import os

from lang import speck
import tqdm


def __cls_or_clear_platform():
    if sys.platform == 'win32':
        return "cls"
    elif sys.platform == 'linux' or sys.platform == 'linux2':
        return "clear"
    elif sys.platform == 'darwin':
        return "clear"
    else:
        return "clear"


mcls = lambda: os.system(__cls_or_clear_platform())

version = '1.2'
prefix = "edit"

loadspeck = speck(prefix)
loadspeck.loadlang()

loadspeck = loadspeck.speck

if __name__ == '__main__':
    File_line = []


    def VIIDE(openfilepath: str):
        name_file = openfilepath.split('/')[-1]
        pathfile = '/'.join(openfilepath.split('/')[:-1])

        def filestatus():
            my_file = []
            for num, line in enumerate(open(openfilepath, 'r', encoding='utf-8').readlines()):
                my_file.append([num + 1, line.replace('\n', '')])

            if my_file == File_line:
                return [True, '']
            else:
                return [False, '*']

        def reopenfile():
            File_line.clear()
            # File_line = []
            for num, line in enumerate(open(openfilepath, 'r', encoding='utf-8').readlines()):
                print([num + 1, line.replace('\n', '')])
                File_line.append([num + 1, line.replace('\n', '')])

        for num, line in enumerate(open(openfilepath, 'r', encoding='utf-8').readlines()):
            print([num + 1, line.replace('\n', '')])
            File_line.append([num + 1, line.replace('\n', '')])

        def save_file():
            with open(openfilepath, 'w', encoding='utf-8') as file:
                for line in tqdm.tqdm(File_line):
                    file.writelines(line[1] + '\n')

        while True:
            mcls()
            print(f'{loadspeck["Have ARG"]["VIIDE"]["File"]} {pathfile}-{name_file}{filestatus()[1]}')
            print(loadspeck['Have ARG']['VIIDE']['HelpCommadMessage'])
            print()

            lenFile_line = len(File_line)

            pr = 3 - len(str(lenFile_line))

            for i in File_line:
                print(f'{i[0]}{" " * (3 - len(str(i[0])))} | {i[1]}')

            comad_or_mess = input(f'{lenFile_line + 1}{" " * pr} | ')
            comad_or_mess = (comad_or_mess if comad_or_mess != '' else ' ')

            if comad_or_mess[0] != '/':
                File_line.append([lenFile_line + 1, comad_or_mess])
            else:
                command = comad_or_mess.split()[0]
                nextatribite = comad_or_mess.split()[1:]
                if len(comad_or_mess.split()) >= 2:
                    atribut = comad_or_mess.split()[1]

                    if command == '/-':
                        try:
                            int(atribut)
                        except:
                            pass
                        else:
                            if len(nextatribite[1:]) != 0:
                                File_line[int(atribut) - 1][1] = ' '.join(nextatribite[1:])
                            else:
                                num = input(f'{atribut}{" " * pr} | {File_line[int(atribut) - 1][1]}> ')
                                File_line[int(atribut) - 1][1] = num
                    elif command == '/del':
                        ismines = False
                        for num, info in enumerate(File_line):
                            if str(info[0]) == ''.join(atribut):
                                del File_line[num]
                                if len(File_line) != 0 and len(File_line) != num:
                                    File_line[num][0]-=1
                                    ismines = True
                            elif ismines:
                                 File_line[num][0]-=1

                    elif command == '/newline':
                        nismines = False
                        copyListline = File_line.copy()
                        for num, info in enumerate(copyListline):
                            print(info, atribut)
                            if int(info[0]) == int(atribut):
                                File_line.insert(num, [num, ''])
                                File_line[num][0] += 1
                                nismines = True
                            if nismines:
                                File_line[num + 1][0] += 1
                else:
                    if command == '/exit':
                        if filestatus()[0] == False:
                            while True:
                                num = input(loadspeck['Have ARG']['VIIDE']['SaveFile'].format(prefix))
                                if num == 'y':
                                    save_file()
                                    break
                                elif num == 'n':
                                    break
                        break

                    elif command == '/save':
                        save_file()

                    elif command == '/reopen':
                        if filestatus()[0] == False:
                            while True:
                                num = input(loadspeck['Have ARG']['VIIDE']['ReOpenFile'].format(prefix))
                                if num == 'y':
                                    reopenfile()
                                    break
                                elif num == 'n':
                                    break

                    # elif command == '/>':
                    #     pass

                    # elif command == '/<':
                    #     pass

                    elif command == '/help':
                        mcls()
                        # print(f"\n [{prefix}] help on '{prefix}' \n  - Exit -> /exit \n  - SaveFile -> /save \n  - Stitch change -> up-/> , down-/< \n [Have Attributes] \n  - Move to selected line -> /- [num-line] \n  - Delete line by number -> /del [num-line]\n")
                        print(loadspeck['Have ARG']['VIIDE']['HelpCommad'].format(prefix))
                        input(loadspeck['EnterPrees'])


    args = sys.argv[1:]

    if len(args) != 1:

        if args[1] == '-help':
            print(loadspeck['Have ARG']['MainHelp'].format(prefix, version))

            input(loadspeck['EnterPrees'])

        elif args[1] == '--info':
            print(loadspeck['Have ARG']['MainInfo'].format(prefix))

        elif args[1] != '':
            mcls()
            if args[1].find('/') == -1:
                if os.path.isfile(args[0] + args[1]):
                    VIIDE(args[0] + args[1])
                else:
                    print(loadspeck['Have ARG']['ErrorNoPath'].format(prefix, args[1]))
                    input(loadspeck['EnterPrees'])
            else:
                if os.path.isfile(args[0] + args[1]):
                    VIIDE(args[0] + args[1])
                else:
                    print(loadspeck['Have ARG']['ErrorNoPath'].format(prefix, args[1]))
                    input(loadspeck['EnterPrees'])

    elif len(args) == 1:
        mcls()
        fileName = None
        while True:
            num = input(loadspeck['Dont Have ARG']['CreateFile'].format(prefix))
            if num == 'y':
                fileName = input(loadspeck['Dont Have ARG']['FileFormat'].format(prefix))
                break
            elif num == 'n':
                break
        if fileName != None:
            open(args[0] + fileName, 'w')
            VIIDE(args[0] + fileName)
