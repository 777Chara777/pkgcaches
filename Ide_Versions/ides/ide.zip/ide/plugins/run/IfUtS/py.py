import sys
import os

msystem = lambda comm : os.system(comm)
misdir = lambda path : os.path.isdir(path)
if __name__ == '__main__':
    args = sys.argv[1:]
    
    if args[1] == '-comp':
        print(f'{args[2]} Python3')

    elif len(args) != 0:
        msystem('python {0} {1}'.format(args[1], ' '.join(args[3:])))
    