from BaseModule import *
from spak import *
import os

prefixpython = 'python3'

loadspeck = speck('$__main__.py')
loadspeck.loadlang()

loadspeck = loadspeck.speck 

if not misdir('pkg/ide/pkgcache/'):
    mkdir('pkg/ide/pkgcache')
if not misdir('pkg/ide/pkgcache/ide/'):
    mkdir('pkg/ide/pkgcache/ide')

ideload = {}
for files in mwhatinfile('pkg/ide/'):
    if files.find('ide_v') != -1:
        ideload[len(ideload)+1] = [len(ideload)+1,files]

ideload_2 = [f'{ideload[x][0]}: {ideload[x][1]}' for x in ideload]
ideload_3 = [ideload[x][1] for x in ideload]

settings = lambda : loadall_json('pkg/ide/pkgcache/ide/settings_ide.json')
if settings() == None:
    print(str(loadspeck['SettingsIDE']['Welcom']).format(" , ".join(ideload_2)))
    for ide in ideload_3:
        # Edit python on the python3
        os.system(f"{prefixpython} pkg/ide/{ide} -info")
    print()
    print(str(loadspeck['SettingsIDE']['IDE!']))

    while True:
        num = input('Num - IDE Version: ')
        try:
            int(num)
        except ValueError:
            pass
        else:
            if ideload.get(int(num)) != None:
                break
    data = {
        'IdeVersion': ideload[int(num)][1]
    }
    input_json('pkg/ide/pkgcache/ide/settings_ide.json', data)

mcls()
while True:
    if misfile('pkg/ide/pkgcache/ide/set') != True:
        open("pkg/ide/pkgcache/ide/set", "w").close()
    temp = open("pkg/ide/pkgcache/ide/set", "r+")
    ii = bool(temp.read())

    if ii:
        if settings()['IdeVersion'] in ideload_3:
            # Edit python on the python3
            os.system(f"{prefixpython} pkg/ide/{settings()['IdeVersion']} -launch")
        break
    else:
        a: str = ""
        while False if a == 'y' or a == 'n' else True:
            a = input(str(loadspeck['InstallC'])).lower()
        if a != "n":
            os.system("apt install gcc")
        open("pkg/ide/pkgcache/ide/set", "w").write(str(True))
        os.system(f"{prefixpython} pkg/ide/{settings()['IdeVersion']} -launch")