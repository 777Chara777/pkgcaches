import sys
import os
import json

from lang import speck


def loadall_json(derictory) -> 'dict | None':
    if misfile(derictory):
        with open(derictory, encoding="utf-8") as config_file:
            data = json.load(config_file)
        return data
    else:
        return None

def __cls_or_clear_platform():
    if "win32" == sys.platform:
        return "cls"
    return "clear"

mconfigide = lambda : loadall_json('pkgcache/ide/settings_ide.json')
mwhatinfilepy = lambda path: [(x[:-3] if x.endswith('.py') else None) for x in os.listdir(path)]
mwhatinfile = lambda path: os.listdir(path)
mcls = lambda: os.system(__cls_or_clear_platform())
misfile = lambda path: os.path.isfile(path)
misdir = lambda path: os.path.isdir(path)

prefix = "view"
python_prefix = mconfigide()['Python']
version = '1.0'

loadspeck = speck(prefix).loadlang()

if __name__ == '__main__':
    args = sys.argv[1:]

    if len(args) != 1:
        if args[1] == '-help':
            print(loadspeck['MainHelp'].format(prefix, version))
            input(loadspeck['EnterPrees'])

        elif args[1] == '--info':
            print(loadspeck['MainInfo'].format(prefix))


        elif args[1] != '':
            filepath = args[0]+args[1]
            if misfile(filepath):
                argscom = {'-start': None, '-end': None}
                f = open(filepath, "r", encoding='utf-8')
                l = f.readlines()
                f.close()

                for num, _arg in enumerate(args[1:]):
                    if _arg in argscom:
                        try:
                            if len(args[1:])-1 >= num+1:
                                int(args[1:][num+1])
                            else:
                                raise IndexError
                        except ValueError:
                            print(loadspeck['ErrorMessage1'].format(prefix, _arg, args[1:][num+1]))
                            input(loadspeck['EnterPrees'])
                            break
                        except IndexError:
                            print(loadspeck['ErrorMessage2'].format(prefix, _arg))
                            input(loadspeck['EnterPrees'])
                            break
                        else:
                            argscom[_arg] = str(args[1:][num+1])

                if argscom['-start'] == None:
                    s = input(loadspeck['StartLineMessage'])
                else:
                    s = argscom['-start']
                if s == "": s="0"
                s=int(s)

                if argscom['-end'] == None:
                    e = input(loadspeck['EndLineMessage'].format(len(l)))
                else:
                    e = argscom['-end']
                if e == "": e= str(len(l))
                e = int(e)
                mcls()

                for i in range(s, e):
                    try:
                        print(l[i])
                    except:
                        break

                input(loadspeck['EnterPrees'])
                
            else:
                print(loadspeck['ErrorPath'].format(prefix, filepath))
                input(loadspeck['EnterPrees'])