import sys
import os

msystem = lambda comm : os.system(comm)
misdir = lambda path : os.path.isdir(path)
mkdir = lambda path : os.mkdir(path)

if __name__ == '__main__':
    args = sys.argv[1:]

    if args[1] == '-comp':
        print(f'{args[2]} C')
    elif len(args) != 0:

        if not misdir('temp/ide/'):
            mkdir('temp/ide')
        if not misdir('temp/ide/builds/'):
            mkdir('temp/ide/builds')

        filename = args[1].split('/')[-1]
        filebuild = filename.split('.')[0]
        try:
            msystem(f'g++ -o temp/ide/builds/{filebuild} {args[1]}')
            msystem(f'chmod +x temp/ide/builds/{filebuild}')
            msystem(f'./temp/ide/builds/{filebuild}')
        except KeyboardInterrupt:
            pass
