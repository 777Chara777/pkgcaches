from BaseModule import dateurl, msystem, mplatform
from LangModule import speck

class CheckVersion:
    def __init__(self, version: str, pyprefix, DownloadIde: str) -> None:
        self.pyprefix = pyprefix
        self.DownloadIde = DownloadIde
        self.speck = speck('$CheckVersion.py')
        self.lang = self.speck.loadlang()
        self.mainVersion = version
        self.date: dict = dateurl('https://raw.githubusercontent.com/777Chara777/pkgcaches/main/Ide_Versions/manifest.json')
        self.check()

    def check(self):
        if self.date['$lastversion'].get('Version') != None and self.date['$versions'].get(self.mainVersion) != None:
            if int(self.date['$lastversion']['Number']) > int(self.date['$versions'][self.mainVersion]['Number']):    
                version = self.date['$lastversion']['Version']
                name = self.date['$lastversion']['Name']

                decriptions = self.speck.specktest(self.date['$lastversion']['Description'])

                def run():
                    if mplatform() == 'win32':
                        msystem(f'start {self.pyprefix} pkgcache/ide/{self.DownloadIde} "{name}{version}" 155432')
                    else:
                        msystem(f'{self.pyprefix} pkgcache/ide/{self.DownloadIde} "{name}{version}" 155432 &')

                print(self.lang['NewVersion'].format(version, self.mainVersion))
                print(self.lang['NewVersionDec'].format("\n - ".join(decriptions)))
                print(self.lang['Update'])

                while True:
                    num = input('[y/n] ')
                    if num == 'y':
                        run()
                        print(f'UpDate IDE "{name}{version}"')
                        exit()
                    elif num == 'n':
                        break

