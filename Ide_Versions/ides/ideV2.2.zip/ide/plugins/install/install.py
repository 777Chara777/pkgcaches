import sys
import os

from lang import speck

python_prefix = 'python'


def __cls_or_clear_platform():
    if "win32" == sys.platform:
        return "cls"
    return "clear"

mwhatinfile = lambda path: os.listdir(path)
mcls = lambda: os.system(__cls_or_clear_platform())
misfile = lambda path: os.path.isfile(path)
misdir = lambda path: os.path.isdir(path)

prefix = "install"
version = '1.0'

loadspeck = speck(prefix)
loadspeck.loadlang()

loadspeck = loadspeck.speck

if __name__ == '__main__':
    args = sys.argv[1:]

    if len(args) != 1:
        if args[1] == '-help':
            print(loadspeck['MainHelp'].format(prefix, version))
            input(loadspeck['EnterPrees'])

        elif args[1] == '--info':
            print(loadspeck['MainInfo'].format(prefix))

        elif args[1] != '':
            os.system(f'pip3 install {" ".join(args[1])}')