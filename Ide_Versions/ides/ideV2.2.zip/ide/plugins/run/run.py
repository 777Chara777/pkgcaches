import sys
import os

from lang import speck

"""

Instructions_for_Using_the_System

"""

python_prefix = 'python3'


def __cls_or_clear_platform():
    if "win32" == sys.platform:
        return "cls"
    return "clear"


mwhatinfilepy = lambda path: [(x[:-3] if x.endswith('.py') else None) for x in os.listdir(path)]
mwhatinfile = lambda path: os.listdir(path)
mcls = lambda: os.system(__cls_or_clear_platform())
misfile = lambda path: os.path.isfile(path)
misdir = lambda path: os.path.isdir(path)

prefix = "run"
version = '2.0'

loadspeck = speck(prefix)
loadspeck.loadlang()

loadspeck = loadspeck.speck

if __name__ == '__main__':
    args = sys.argv[1:]
    pathinst = f'pkg/ide/plugins/{prefix}/IfUtS/'
    Path_Instructions_for_Using_the_System = mwhatinfilepy(pathinst)

    if len(args) != 1:
        if args[1] == '-help':
            print(loadspeck['MainHelp'].format(prefix, version))
            input(loadspeck['EnterPrees'])

        elif args[1] == '--info':
            print(loadspeck['MainInfo'].format(prefix))


        elif args[1] != '':
            fileformat = args[1].split('.')[1]
            if fileformat in Path_Instructions_for_Using_the_System:
                if misfile(args[0] + args[1]):
                    mcls()
                    print(loadspeck['StartFileMessage'].format(args[1]))
                    os.system(
                        f'{python_prefix} {pathinst}{fileformat}.py {pathinst} -comp "{loadspeck["CompilerMessage"]}"')
                    print()
                    if len(args[1:]) != 0:
                        os.system(
                            f'{python_prefix} {pathinst}{fileformat}.py {pathinst} {args[0]}{args[1]} {" ".join(args[1:])}')
                    else:
                        os.system(f'{python_prefix} {pathinst}{fileformat}.py {pathinst} {args[0]}{args[1]}')
                    print()
                    input(loadspeck['EnterPrees'])
                else:
                    print(loadspeck['ErrorPath'].foramt(prefix, args[1]))
                    input(loadspeck['EnterPrees'])
