import os
import shutil

from LangModule import *

from sys import argv
from BaseModule import *

loadspeck = speck('$IDE_V1.2a')
loadspeck = loadspeck.loadlang()

minedirpath = None
path = 'pkgcache/ide/projects'
version = '1.2a'
doc = loadspeck['Documentation']
prefix = f'IDEv{version}'

python_prefix = 'python3'

emoji = {
    'dir': '📁 {0}',
    'opendir': '🗃️  {0}',
    'dirhavefile': '🗂️  {0}',
    'rename': '📝  {0}',
    'edit': '✏️  {0}',
    'install': '📦 {0}',
    'cd': '⤵️  {0}',
    'exit': '❌ {0}',
    'runer': '🏃 {0}',
    'delete': '🗑️  {0}',
    'copy': '📑 {0}',
    'move': '🧳 {0}',
    'file': '📄 {0}',
    'other': [
        '─{0}', 
        '└{0}', 
        '├{0}',
        ' {0}'
    ]
}

ListLoadPlugins = []
for plugin in mwhatinfile('pkg/ide/plugins'):
    if misfile(f'pkg/ide/plugins/{plugin}/{plugin}.py'):
        ListLoadPlugins.append(plugin)

def setup():
    global minedirpath, path
    if not misdir("pkgcache/ide/projects"):
        mkdir("pkgcache/ide/projects")
    a: str = '' if len(mwhatinfile('pkgcache/ide/projects')) != 0 else 'c'
    if a == '':
        while True:
            a = input(loadspeck['setup']['ProjectCreateorOpen'].format(prefix))
            if a == 'o' or a == 'c':
                break
    if a == 'o':
        dirinfo = mwhatinfile('pkgcache/ide/projects/')
        print()
        for i in range(len(dirinfo)):
            print(f"{i}) {emoji['dir'].format(dirinfo[i])}")
        print()
        while True:
            num = input(loadspeck['setup']['OpenFile'].format(prefix))
            try:
                int(num)
            except ValueError:
                pass
            else:
                if len(dirinfo) < int(num):
                    print(loadspeck['setup']['ErrorNotFindNumber'].format(prefix, num))
                    input(loadspeck['EnterPrees'])
                else:
                    nd = dirinfo[int(num)]
                    break
    elif a == 'c':
        versionprogect: str = ''
        while True:
            n = input(loadspeck['setup']['HackOSPackageorProject'].format(prefix))
            if n == '1' or n == '2':
                break
        if n == '1':
            versionprogect = input(loadspeck['setup']['HackOSPackageVersion'].format(prefix))
        while True:
            nd = versionprogect + input(loadspeck['setup']['CreateFile'].format(prefix))
            if not misdir(f'pkgcache/ide/projects/{nd}'):
                mkdir(f'pkgcache/ide/projects/{nd}')
                if n == '1':
                    open(f'pkgcache/ide/projects/{nd}/install', 'w')
                    open(f'pkgcache/ide/projects/{nd}/main.py', 'w')
                break
            else:
                print(loadspeck['setup']['ErrorIsFile'].format(prefix))
    minedirpath = nd
    path = f"pkgcache/ide/projects/{nd}"

def lsfileandemoji():
    FileArchitecture = [f'{emoji["opendir"].format("/".join(path.split("/")[3:]))}']
    files = mwhatinfile(path+'/')
    for num, fileordir in enumerate(files):
        if misdir(path+'/'+fileordir):
            dirand = emoji['other'][0].format(emoji['dir' if len(mwhatinfile(path+'/'+fileordir)) == 0 else 'dirhavefile'].format(f'{fileordir} '+ ('' if len(mwhatinfile(path+'/'+fileordir)) == 0 else '*')))
            # dirhavefile dir
            if len(files) != num+1:
                FileArchitecture.append(emoji['other'][2].format(dirand))
            else:
                FileArchitecture.append(emoji['other'][1].format(dirand))        
        elif misfile(path+'/'+fileordir):
            filep = emoji['other'][0].format(emoji['file'].format(fileordir))
            if len(files) != num+1:
                FileArchitecture.append(emoji['other'][2].format(filep))
            else:
                FileArchitecture.append(emoji['other'][1].format(filep))
    return FileArchitecture

def Notfile():
    if len(mwhatinfile(f'{path}')) == 0:
        print(loadspeck['NotFile']['HelpMessage'].format(emoji["dir"].format("Create Dir"),emoji["file"].format("Create File"),emoji["cd"].format("Cd")))

def CreateDir():
    try:
        pathfile = input(loadspeck['CreateDir']['dirname']) 
        if not misdir(path+'/'+pathfile):
            os.mkdir(path+'/'+pathfile)
        else:
            print(loadspeck['CreateDir']['didetect'].format(pathfile))
            input(loadspeck['EnterPrees'])
    except KeyboardInterrupt:
        pass

def CreateFile():
    try:
        pathfile = input(loadspeck['CreateFile']['filename'])
        if not misfile(path+'/'+pathfile):
            open(path+'/'+pathfile, 'w')
        else:
            while True:
                num = input(loadspeck['CreateFile']['fileyesorno'])
                if num == 'y' or num == 'n':
                    break
            if num == 'y':
                open(path+'/'+pathfile, 'w') 
    except KeyboardInterrupt:
        pass

def cdwe(commands: str):
    try:
        global path
        if commands == '..':
            setup()
        elif commands == '.':
            if path != f'pkgcache/ide/projects/{minedirpath}':
                pp = path.split('/')
                path = '/'.join(pp[:-1])
        else:
            if misdir(path+f'/{commands}'):
                path = path+f'/{commands}'
            else:
                print(loadspeck['cdwe']['cdErrorpath'].format(commands))
                input()
    except KeyboardInterrupt:
        pass

def reloadpluagins():
    pluginsnow = []
    for plugin in mwhatinfile('pkg/ide/plugins'):
        if plugin not in ListLoadPlugins:
            ListLoadPlugins.append(plugin)
        pluginsnow.append(plugin)
    
    for num, i in enumerate(ListLoadPlugins):
        if i not in pluginsnow:
            del ListLoadPlugins[num]

if __name__ == '__main__':
    args = argv[1:]
    
    if args[0] == '-info':
        print(f'[{prefix}] - {doc}')
    elif args[0] == '-launch':

        setup()
        while True:    
            mcls()
            print('\n'.join(lsfileandemoji()))
            Notfile()
            print()
            command = input(f'[{prefix}] -> ')

            if mexists(path+f'/{command}') and command != '.' and command.replace(' ','') != '':
                fileordir = command
                filedol = "file" if misfile(path+f"/{command}") else "dir"
                command_num = None
                while True:
                    mcls()
                    if filedol == 'file':
                        print(loadspeck['Menu']['PrintFileHelp'].format((emoji["delete"].format("Delete")),(emoji["edit"].format("Rename")),(emoji["copy"].format("Copy")),(emoji["move"].format("Move")),(emoji["edit"].format("Edit")),(emoji["runer"].format("Run File")),(emoji['install'].format("Install")),(emoji["exit"].format("Exit"))))
                    
                    elif filedol == 'dir':
                        print(loadspeck['Menu']['PrintDirHelp'].format(emoji["delete"].format("Delete"),emoji["edit"].format("Rename"),emoji["copy"].format("Copy"),emoji["move"].format("Move"),emoji["cd"].format("Cd"),emoji["exit"].format("Exit")))
                    
                    commad = input(f'[{prefix}] {emoji[filedol].format(fileordir)} -> ')
                    try:
                        int(commad)
                    except ValueError:
                        pass
                    else:
                        if filedol == 'dir' and int(commad) == 5:
                            break
                        elif filedol == 'file' and int(commad) == 7:
                            break

                        elif int(commad) <= 6: 
                            command_num = int(commad)
                            break
                if command_num == 0:
                    try:
                        num = ''
                        while (False if num == 'y' or num == 'n' else True):
                            num = input(loadspeck['Menu']['RemoveFile'])
                        if num == 'y':
                            if filedol == 'file':
                                os.remove(path+f'/{fileordir}')
                            elif filedol == 'dir':
                                shutil.rmtree(path+f'/{fileordir}')
                    except KeyboardInterrupt:
                        pass

                elif command_num == 1:
                    try:
                        while True:
                            filename = input(loadspeck['Menu']['ReName'])
                            if not mexists(path+f'/{filename}'):
                                break
                        os.rename(path+f'/{command}', path+f'/{filename}')
                    except KeyboardInterrupt:
                        pass
            
                elif command_num == 2:
                    newfile = input(loadspeck['Menu']['CopyFile'])
                    if misfile(path+f'/{fileordir}'):
                        shutil.copy(path+f'/{fileordir}', path+f'/{newfile}')
                    elif misdir(path+f'/{fileordir}'):
                        shutil.copytree(path+f'/{fileordir}', path+f'/{newfile}')
                    else:
                        print(loadspeck['Menu']['CopyFile'].format(newfile))
                        input(loadspeck['EnterPrees'])

                elif command_num == 3:
                    newfile = input(loadspeck['Menu']['MoveFile'])
                    if misdir(path+f'/{newfile}'):
                        shutil.move(path+f'/{fileordir}', path+f'/{newfile}')
                    else:
                        print(loadspeck['Menu']['MoveFileError'])
                        input(loadspeck['EnterPrees'])

                elif command_num == 4:
                    if filedol == 'file':
                        # Edit python on the python3
                        try:
                            reloadpluagins()
                            if 'edit' in ListLoadPlugins:
                                msystem(f'{python_prefix} pkg/ide/plugins/edit/edit.py {path}/ {fileordir}')
                            else:
                                print(loadspeck['Menu']["editPluginError"].format(prefix))
                                input(loadspeck['EnterPrees'])
                        except KeyboardInterrupt:
                            pass
                    elif filedol == 'dir':
                        cdwe(fileordir)
                
                elif command_num == 5:
                    try:
                        reloadpluagins()
                        if 'run' in ListLoadPlugins:
                            msystem(f'{python_prefix} pkg/ide/plugins/run/run.py {path}/ {fileordir}')
                        else:
                            print(loadspeck['Menu']['runPluginError'].format(prefix))
                            input(loadspeck['EnterPrees'])
                    except KeyboardInterrupt:
                        pass

                elif command_num == 6 and filedol == 'file':
                    try:
                        reloadpluagins()
                        pathandfileordir = path+'/'+fileordir
                        if pathandfileordir.split('/')[-1] in ['install','install.sh'] and 'install' in ListLoadPlugins:
                            if pathandfileordir.split('/')[-1] == 'install.sh':
                                oneline = open(f'{pathandfileordir}', 'r').readlines(0)
                                if str(oneline[0]).split()[0] in ['pip', 'pip3']:
                                    for line in open(f'{pathandfileordir}', 'r').readlines():
                                        msystem(line.replace('\n', ''))
                                else:
                                    for line in open(f'{pathandfileordir}', 'r').readlines():
                                        msystem(f'{python_prefix} pkg/ide/plugins/install/install.py '+ line.replace("\n", ""))
                                        input()
                            else:
                                for line in open(f'{pathandfileordir}', 'r').readlines():
                                    print('3', line.replace('\n', ''))
                                    msystem(f'{python_prefix} pkg/ide/plugins/install/install.py '+ line.replace("\n", ""))
                        else:
                            if 'install' in ListLoadPlugins:
                                print(loadspeck['Install']['Messagepip'])
                                installfiles = input(loadspeck['Install']['Inputipip'])
                                msystem(f'{python_prefix} pkg/ide/plugins/install/install.py {installfiles}')
                            else:
                                print(loadspeck['Menu']['installPluginError'].format(prefix))
                                input(loadspeck['EnterPrees'])
                    except KeyboardInterrupt:
                        pass
                
            elif command.strip() == 'exit':
                print(f'exit {prefix}')
                exit()

            elif command.replace(' ', '') == '':
                pass
            
            elif command == '0':
                CreateDir()
            elif command == '1':
                CreateFile()
            elif command == '2':
                if path.split('/')[-1] == minedirpath:
                    mcls()
                    cdwe('..')
                else:
                    cdwe('.')

            else:
                print(loadspeck['Menu']['ErrorPath'].format(prefix,command))
                input(loadspeck['EnterPrees'])
