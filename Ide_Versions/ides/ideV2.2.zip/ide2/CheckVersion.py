from BaseModule import dateurl, msystem, mplatform
from LangModule import speck

class CheckVersion:
    def __init__(self, version: str, pyprefix) -> None:
        self.pyprefix = pyprefix
        self.speck = speck('$CheckVersion.py')
        self.lang = self.speck.loadlang()
        self.mainVersion = version
        self.date: dict = dateurl('https://raw.githubusercontent.com/777Chara777/pkgcaches/main/Ide_Versions/manifest.json')
        self.check()

    def check(self):
        if self.date['$lastversion'].get('Version') != None and self.date['$versions'].get(self.mainVersion) != None:
            if int(self.date['$lastversion']['Number']) > int(self.date['$versions'][self.mainVersion]['Number']):    
                version = self.date['$lastversion']['Version']
                name = self.date['$lastversion']['Name']
                url = self.date['$lastversion']['url']

                decriptions = self.speck.specktest(self.date['$lastversion']['Description'])

                print(self.lang['NewVersion'].format(version, self.mainVersion))
                print(self.lang['NewVersionDec'].format("\n - ".join(decriptions)))
                print(self.lang['Update'].format(url))
                input(self.lang['EnterPrees'])


