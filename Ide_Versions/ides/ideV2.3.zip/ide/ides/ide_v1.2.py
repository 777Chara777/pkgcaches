import os
import shutil

from sys import argv

from mod.LangModule import *
from mod.BaseModule import *

class IDE:
    def __init__(self) -> None:
        self.loadspeck = speck('$IDE_V1.2').loadlang()
        self.IDeVersion = '1.2'
        self.doc = self.loadspeck['Documentation']
        self.prefix = f'IDEv{self.IDeVersion}'
        self.python_prefix = mconfigide()['Python']

        self.rootdir = None
        self.rootpath = 'pkgcache/ide/projects'

        self.emoji = {
            'dir': '📁 {0}',
            'opendir': '🗃️  {0}',
            'dirhavefile': '🗂️  {0}',
            'file': '📄 {0}',
            'other': [
                '─{0}',
                '└{0}',
                '├{0}',
                ' {0}'
            ]
        }
        self.ListLoadPlugins = []
        for plugin in mwhatinfile('pkg/ide/plugins'):
            if misfile(f'pkg/ide/plugins/{plugin}/{plugin}.py'):
                self.ListLoadPlugins.append(plugin)

    def setup(self):
        if not misdir("pkgcache/ide/projects"):
            mkdir("pkgcache/ide/projects")
        a: str = '' if len(mwhatinfile('pkgcache/ide/projects')) != 0 else 'c'
        if a == '':
            while True:
                a = input(self.loadspeck['setup']['ProjectCreateorOpen'].format(self.prefix))
                if a == 'o' or a == 'c':
                    break
        if a == 'o':
            dirinfo = mwhatinfile('pkgcache/ide/projects/')
            print()
            for i in range(len(dirinfo)):
                print(f"{i}) {self.emoji['dir'].format(dirinfo[i])}")
            print()
            while True:
                num = input(self.loadspeck['setup']['OpenFile'].format(self.prefix))
                try:
                    int(num)
                except ValueError:
                    pass
                else:
                    if len(dirinfo) < int(num):
                        print(self.loadspeck['setup']['ErrorNotFindNumber'].format(self.prefix, num))
                        input(self.loadspeck['EnterPrees'])
                    else:
                        nd = dirinfo[int(num)]
                        break
        elif a == 'c':
            versionprogect: str = ''
            while True:
                n = input(self.loadspeck['setup']['HackOSPackageorProject'].format(self.prefix))
                if n == '1' or n == '2':
                    break
            if n == '1':
                versionprogect = input(self.loadspeck['setup']['HackOSPackageVersion'].format(self.prefix))
            while True:
                nd = versionprogect + input(self.loadspeck['setup']['CreateFile'].format(self.prefix))
                if not misdir(f'pkgcache/ide/projects/{nd}'):
                    mkdir(f'pkgcache/ide/projects/{nd}')
                    if n == '1':
                        open(f'pkgcache/ide/projects/{nd}/install', 'w')
                        open(f'pkgcache/ide/projects/{nd}/main.py', 'w')
                    break
                else:
                    print(self.loadspeck['setup']['ErrorIsFile'].format(self.prefix))

        self.rootdir = nd
        self.rootpath = f"pkgcache/ide/projects/{nd}"

    def lsfileandemoji(self):
        FileArchitecture = [f'{self.emoji["opendir"].format("/".join(self.rootpath.split("/")[3:]))}']
        files = mwhatinfile(self.rootpath)
        for num, fileordir in enumerate(files):
            if misdir(self.rootpath + '/' + fileordir):
                dirand = self.emoji['other'][0].format(self.emoji['dir' if len(mwhatinfile(self.rootpath+'/'+fileordir)) == 0 else 'dirhavefile'].format(f'{fileordir} '+ ('' if len(mwhatinfile(self.rootpath+'/'+fileordir)) == 0 else '*')))
                if len(files) != num + 1:
                    FileArchitecture.append(self.emoji['other'][2].format(dirand))
                else:
                    FileArchitecture.append(self.emoji['other'][1].format(dirand))
            elif misfile(self.rootpath + '/' + fileordir):
                filep = self.emoji['other'][0].format(self.emoji['file'].format(fileordir))
                if len(files) != num + 1:
                    FileArchitecture.append(self.emoji['other'][2].format(filep))
                else:
                    FileArchitecture.append(self.emoji['other'][1].format(filep))
        return FileArchitecture


    def reloadplugins(self):
        pluginsnow = []
        for plugin in mwhatinfile('pkg/ide/plugins'):
            if misfile(f'pkg/ide/plugins/{plugin}/{plugin}.py'):
                if plugin not in self.ListLoadPlugins:
                    self.ListLoadPlugins.append(plugin)
                pluginsnow.append(plugin)

        for num, i in enumerate(self.ListLoadPlugins):
            if i not in pluginsnow:
                del self.ListLoadPlugins[num]

    def Run(self):
        args = argv[1:]

        if args[0] == '-info':
            print(f'[{self.prefix}] - {self.doc}')
        elif args[0] == '-launch':
            self.setup()

            while True:
                mcls()
                print(self.loadspeck['Menu']["helpCommand"])
                print('\n'.join(self.lsfileandemoji()))
                print()

                command = input(f'[{self.prefix}] >>> ').split(' ')
                comadname = command[0]
                comadargs = command[1:]

                if comadname in self.ListLoadPlugins:
                    try:
                        self.reloadplugins()
                        msystem(f'{self.python_prefix} pkg/ide/plugins/{comadname}/{comadname}.py {self.rootpath}/ {" ".join(comadargs)}')
                    except KeyboardInterrupt:
                        pass
                else:
                    self.commands(comadname, comadargs)

    def commands(self, comadname: str, comadargs: str):
        if comadname == 'exit':
            print(f'exit {self.prefix}')
            exit()

        elif comadname == 'cd':
            try:
                if len(comadargs) != 0 and misdir(f'pkgcache/ide/projects/{self.rootdir}'):
                    if comadargs[0] == '..':
                        self.rootpath = f"pkgcache/ide/projects/{self.rootdir}"
                    elif comadargs[0] == '.':
                        if self.rootpath != f'pkgcache/ide/projects/{self.rootdir}':
                            pp = self.rootpath.split('/')
                            self.rootpath = '/'.join(pp[:-1])
                    else:
                        if misdir(self.rootpath + '/' + comadargs[0]):
                            if comadargs[0][0] == '.':
                                lis = (comadargs[0].split('/'))
                                del lis[0]
                                comadargs[0] = '/'.join(lis)
                            self.rootpath = self.rootpath + '/' + ('/'.join(comadargs[0].split('/')))
                        else:
                            print(self.loadspeck['CD']['CDError'].format(comadargs[0]))
                            input(self.loadspeck['EnterPrees'])
            except KeyboardInterrupt:
                pass

        elif comadname == 'mkfile':
            try:
                if comadargs != []:
                    if not misfile(self.rootpath + '/' + comadargs[0]):
                        open(self.rootpath + '/' + comadargs[0], 'w')
                    else:
                        while True:
                            num = input(self.loadspeck['MkFile']['RecreateFile'])
                            if num == 'y' or num == 'n':
                                break
                        if num == 'y':
                            open(self.rootpath + '/' + comadargs[0], 'w')
                else:
                    pathfile = input(self.loadspeck['MkFile']['MenuCreate'])
                    if not misfile(self.rootpath + '/' + pathfile):
                        open(self.rootpath + '/' + pathfile, 'w')
                    else:
                        while True:
                            num = input(self.loadspeck['MkFile']['RecreateFile'])
                            if num == 'y' or num == 'n':
                                break
                        if num == 'y':
                            open(self.rootpath + '/' + pathfile, 'w')
            except KeyboardInterrupt:
                pass

        elif comadname == 'rm':
            if comadargs != []:
                num = ''
                while (False if num == 'y' or num == 'n' else True):
                    num = input(self.loadspeck["RM"]['DeleteFile'])
                if num == 'y':
                    if misfile(self.rootpath + f'/{comadargs[0]}'):
                        os.remove(self.rootpath + f'/{comadargs[0]}')
                    elif misdir(self.rootpath + f'/{comadargs[0]}'):
                        shutil.rmtree(self.rootpath + f'/{comadargs[0]}')
            else:
                pathfile = input(self.loadspeck["RM"]['MenuDelete'])
                if mexists(pathfile):
                    num = ''
                    while (False if num == 'y' or num == 'n' else True):
                        num = input(self.loadspeck["RM"]['DeleteFile'])
                    if num == 'y':
                        if misfile(self.rootpath + f'/{comadargs[0]}'):
                            os.remove(self.rootpath + f'/{comadargs[0]}')
                        elif misdir(self.rootpath + f'/{comadargs[0]}'):
                            shutil.rmtree(self.rootpath + f'/{comadargs[0]}')

        elif comadname == 'mv':
            try:
                if comadargs != []:
                    if len(comadargs) == 2:
                        if misfile(self.rootpath + f'/{comadargs[0]}') and misdir(self.rootpath + f'/{comadargs[1]}'):
                            shutil.move(self.rootpath + f'/{comadargs[0]}', self.rootpath + f'/{comadargs[1]}')
                        else:
                            print(self.loadspeck['MV']['MVErrorArgs'])
                            input(self.loadspeck['EnterPrees'])
                    else:
                        print(self.loadspeck['MV']['MVErrorPath'])
                        input(self.loadspeck['EnterPrees'])
                else:
                    oldfile = input(self.loadspeck['MV']['MVMenuFile'])
                    newfile = input(self.loadspeck['MV']['MVMenuDir'])
                    if misfile(self.rootpath + f'/{oldfile}') and misdir(self.rootpath + f'/{newfile}'):
                        shutil.move(self.rootpath + f'/{oldfile}', self.rootpath + f'/{newfile}')
                    else:
                        print(self.loadspeck['MV']['MVErrorArgs'])
                        input(self.loadspeck['EnterPrees'])
            except KeyboardInterrupt:
                pass

        elif comadname == 'cp':
            try:
                if len(comadargs) != 0:
                    if len(comadargs) == 2:
                        if misfile(self.rootpath + f'/{comadargs[0]}'):
                            shutil.copy(self.rootpath + f'/{comadargs[0]}', self.rootpath + f'/{comadargs[1]}')
                        elif misdir(self.rootpath + f'/{comadargs[0]}'):
                            shutil.copytree(self.rootpath + f'/{comadargs[0]}', self.rootpath + f'/{comadargs[1]}')
                    else:
                        print(self.loadspeck['CP']['CPErrorOldtoNew'])
                        input(self.loadspeck['EnterPrees'])

                else:
                    oldfile = input(self.loadspeck['CP']['CPMenuOldFile'])
                    newfile = input(self.loadspeck['CP']['CPMenuNewFile'])
                    if misfile(self.rootpath + f'/{oldfile}'):
                        shutil.copy(self.rootpath + f'/{oldfile}', self.rootpath + f'/{newfile}')
                    elif misdir(self.rootpath + f'/{oldfile}'):
                        shutil.copytree(self.rootpath + f'/{oldfile}', self.rootpath + f'/{newfile}')
                    else:
                        print(self.loadspeck['CP']['CPMenuPathError'].format(oldfile, newfile))
                        input(self.loadspeck['EnterPrees'])
            except KeyboardInterrupt:
                pass

        elif comadname == 'rename':
            try:
                if comadargs != []:
                    if len(comadargs) == 2:
                        if mexists(self.rootpath + f'/{comadargs[0]}'):
                            os.rename(self.rootpath + f'/{comadargs[0]}', self.rootpath + f'/{comadargs[1]}')
                    else:
                        print(self.loadspeck['ReName']['ReNameErrorOldtoNew'])
                        input(self.loadspeck['EnterPrees'])
                else:
                    oldfile = input(self.loadspeck['ReName']['ReNameMenuOldFile'])
                    newfile = input(self.loadspeck['ReName']['ReNameMenuNewFile'])
                    if mexists(self.rootpath + f'/{oldfile}'):
                        os.rename(self.rootpath + f'/{oldfile}', self.rootpath + f'/{newfile}')
                    else:
                        print(self.loadspeck['ReName']['ReNameMenuErrorPath'].format(oldfile))
                        input(self.loadspeck['EnterPrees'])
            except KeyboardInterrupt:
                pass

        elif comadname == 'mkdir':
            try:
                if comadargs != []:
                    try:
                        if comadargs[0].find('/') == -1:
                            os.mkdir(self.rootpath + '/' + comadargs[0])
                        else:
                            path_to_file = comadargs[0].split('/')[:-1]
                            if not misdir('/'.join(path_to_file)):
                                os.mkdir(self.rootpath + '/' + comadargs[0])
                    except FileNotFoundError:
                        print(self.loadspeck['MkDir']['MkDirError'])
                        input(self.loadspeck['EnterPrees'])
                else:
                    pathfile = input(self.loadspeck['MkDir']['MkDirDirNamePath'])
                    path_to_file = pathfile.split('/')[:-1]
                    if path_to_file != []:
                        if not misdir(self.rootpath + '/' + path_to_file):
                            os.mkdir(self.rootpath + '/' + pathfile)
                        else:
                            print(self.loadspeck['MkDir']['MkDirDirNameError'])
                            input(self.loadspeck['EnterPrees'])
                    else:
                        if not misdir(self.rootpath + '/' + path_to_file):
                            os.mkdir(self.rootpath + '/' + pathfile)
            except FileExistsError:
                print(self.loadspeck['MkDir']['MkDirFileExistsError'])
                input(self.loadspeck['EnterPrees'])
            except KeyboardInterrupt:
                pass
            else:
                print(self.loadspeck['MkDir']['MkDirFileCreate'])

        elif comadname == 'help':
            mcls()
            print(self.loadspeck['IDEHelp']['idehelpmessage'])
            for plug in self.ListLoadPlugins:
                msystem(f'{self.python_prefix} pkg/ide/plugins/{plug}/{plug}.py {self.rootpath} --info')
            print(self.loadspeck['IDEHelp']['idehelpstop'])
            input(self.loadspeck['EnterPrees'])

        elif comadname == 'newdirectory':
            mcls()
            self.setup()
    

if __name__ == '__main__':
    ide = IDE()
    ide.Run()