from ides.mod.BaseModule import dateurl
from ides.mod.LangModule import *

class CheckVersion:
    def __init__(self, VersionId: str) -> None:
        self.speck = speck('$CheckVersion.py')
        self.lang = self.speck.loadlang()
        self.mainVersion = VersionId
        self.date: dict = dateurl('https://raw.githubusercontent.com/777Chara777/pkgcaches/main/Ide_Versions/manifest.json')
        self._check()

    def _check(self):
        if self.date['$lastversion'].get('Version') != None and self.date['$versions'].get(self.mainVersion) != None:
            if int(self.date['$lastversion']['Number']) > int(self.date['$versions'][self.mainVersion]['Number']):    
                version = self.date['$lastversion']['Version']
                url = self.date['$lastversion']['url']

                decriptions = self.speck.specktest(self.date['$lastversion']['Description'])

                print(self.lang['NewVersion'].format(version, self.mainVersion))
                print(self.lang['NewVersionDec'].format("\n - ".join(decriptions)))
                print(self.lang['Update'].format(url))
                input(self.lang['EnterPrees'])
    
    def CheckVersion(self) -> 'int | None':
        try:
            return int(self.date['$versions'][self.mainVersion]['Number'])
        except:
            return None