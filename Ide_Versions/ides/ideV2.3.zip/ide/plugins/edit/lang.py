import json
import os

mwhatinfile = lambda path: os.listdir(path)
misfile = lambda path: os.path.isfile(path)


def loadall_json(derictory) -> dict:
    if misfile(derictory):
        with open(derictory, encoding="utf-8") as config_file:
            data = json.load(config_file)
        return data
    else:
        return None


def SpeckSystem() -> str:
    with open('.lset', 'r', encoding='utf-8') as file:
        return file.readline()


class speck:
    def __init__(self, filename):
        with open(".lset", encoding='utf-8') as f:
            self.sysnamelang: str = f.readline()
        self.idelangfile: dict = loadall_json(f'pkg/ide/plugins/{filename}/lang/lang.json')
        self.speck = None

    def loadlang(self):
        self.speck = self.idelangfile[self.sysnamelang]
