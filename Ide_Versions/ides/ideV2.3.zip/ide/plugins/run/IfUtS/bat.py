import sys
import os

msystem = lambda comm : os.system(comm)
misdir = lambda path : os.path.isdir(path)
if __name__ == '__main__':
    args = sys.argv[1:]
    
    if args[1] == '-comp':
        print(f'{args[2]} Bath')

    elif len(args) != 0:
        # with open(args[1], "r") as f:
        #     for line in f.readlines():
        #         msystem(line)
        #         i = input()
        #         if i == "f":
        #             pass # просмотр проекта
        #         elif i == "exit":
        #             exit()
        try:
            msystem(f'{args[1]}')
        except KeyboardInterrupt:
            pass