from BaseModule import *
from LangModule import *
from CheckVersion import *
from shutil import move
import os

"""
Main File Wow
 - version 1.1 Circumcision version
 - by *-chara-*#7034
"""

# Edit python on the python3
prefixpython = 'python'

loadspeck = speck('$__main__.py')
loadspeck = loadspeck.loadlang()

version = 'V2.1'
DownloadIde = 'Downloadide1.py'


if misfile(f'pkg/ide/{DownloadIde}.py'):
    if not misdir(f'pkgcache/ide'):
        mkdir(f'pkgcache/ide')
    if misfile(f'pkgcache/ide/{DownloadIde}.py'):
        os.remove(f'pkgcache/ide/{DownloadIde}.py')
    move(f'pkg/ide/{DownloadIde}.py', 'pkgcache/ide/')

ideload = {}
for files in mwhatinfile('pkg/ide/'):
    if files.find('ide_v') != -1:
        ideload[len(ideload)+1] = [len(ideload)+1,files]

ideload_2 = [f'{ideload[x][0]}: {ideload[x][1]}' for x in ideload]
ideload_3 = [ideload[x][1] for x in ideload]

CheckVersion(version, prefixpython, DownloadIde)

settings = lambda : loadall_json('pkgcache/ide/settings_ide.json')
if settings() == None:
    print(f'IDE {version}')
    print(str(loadspeck['SettingsIDE']['Welcom']).format(" , ".join(ideload_2)))
    for ide in ideload_3:
        os.system(f"{prefixpython} pkg/ide/{ide} -info")
    print()
    print(str(loadspeck['SettingsIDE']['IDE!']))

    while True:
        num = input('Num - IDE Version: ')
        try:
            int(num)
        except ValueError:
            pass
        else:
            if ideload.get(int(num)) != None:
                break
    data = {
        'IdeVersion': ideload[int(num)][1]
    }
    input_json('pkgcache/ide/settings_ide.json', data)

mcls()
while True:
    if misfile('pkgcache/ide/set') != True:
        open("pkgcache/ide/set", "w").close()
    temp = open("pkgcache/ide/set", "r+")
    ii = bool(temp.read())

    if ii:
        if settings()['IdeVersion'] in ideload_3:
            os.system(f"{prefixpython} pkg/ide/{settings()['IdeVersion']} -launch")
        break
    else:
        a: str = ""
        while False if a == 'y' or a == 'n' else True:
            a = input(str(loadspeck['InstallC'])).lower()
        if a != "n":
            os.system("apt install gcc")
            os.system("apt install g++")
        open("pkgcache/ide/set", "w").write(str(True))
        os.system(f"{prefixpython} pkg/ide/{settings()['IdeVersion']} -launch")