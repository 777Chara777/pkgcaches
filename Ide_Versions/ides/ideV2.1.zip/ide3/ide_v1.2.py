import os
import shutil

from LangModule import *

from sys import argv
from BaseModule import *

loadspeck = speck('$IDE_V1.2')
loadspeck = loadspeck.loadlang()

minedirpath = None
path = 'pkgcache/ide/projects'
version = '1.2'
doc = loadspeck['Documentation']
prefix = f'IDEv{version}'

python_prefix = 'python3'

emoji = {
    'dir': '📁 {0}',
    'opendir': '📂 {0}',
    'file': '📄 {0}',
    'other': [
        '─{0}',
        '└{0}',
        '├{0}',
        ' {0}'
    ]
}

ListLoadPlugins = []
for plugin in mwhatinfile('pkg/ide/plugins'):
    if misfile(f'pkg/ide/plugins/{plugin}/{plugin}.py'):
        ListLoadPlugins.append(plugin)


def setup():
    global minedirpath, path, PackageorProject
    if not misdir("pkgcache/ide/projects"):
        mkdir("pkgcache/ide/projects")

    PackageorProject = None

    while True:
        a = input(loadspeck['setup']["Package OR Project"].format(prefix)).lower() #
        if a in '01':
            if a == '1':
                PackageorProject = 'pro'
            elif a == '0':
                PackageorProject = 'pac'
            break

    a: str = ""
    if len(mwhatinfile(path)) == 0:
        a = 'c'
    else:
        while True:
            try:
                if PackageorProject == 'pro':
                    a = input(loadspeck['setup']["ProjectCreateorOpen"].format(prefix)).lower() #
                else:
                    a = input(loadspeck['setup']["PackageCreateorOpen"].format(prefix)).lower() #
                if a in 'oc':
                    break

            except KeyboardInterrupt:
                exit()
    if a == "c":
        while True:
            if PackageorProject == 'pro':
                pn = input(loadspeck['setup']["CreateFile"].format(prefix)).split()[0] #
            else:
                pn = input(loadspeck['setup']["CreatePackage"].format(prefix)).split()[0] #
            if not misdir(f'{path}/{pn}'):
                mkdir(f"{path}/{pn}")
                if PackageorProject == 'pac':
                    open(f'{path}/{pn}/main.py', 'w')
                    open(f'{path}/{pn}/install', 'w')
                break
            else:
                print(loadspeck['setup']["ErrorIsFile"].format(prefix, pn))
    elif a == "o":
        dir = os.listdir('pkgcache/ide/projects/')

        print()
        for i in range(len(dir)):
            print(f"{i}) {emoji['dir'].format(dir[i])}")
        print()
        while True:
            if PackageorProject == 'pro':
                n = input(loadspeck['setup']["OpenFile"].format(prefix)) #
            else:
                n = input(loadspeck['setup']["OpenPackage"].format(prefix)) #
            try:
                int(n)
            except ValueError:
                pass
            else:
                pn = dir[int(n)]
                break

    minedirpath = pn
    path = f"pkgcache/ide/projects/{pn}"

def lsfileandemoji():
    FileArchitecture = [f'{emoji["opendir"].format("/".join(path.split("/")[3:]))}']
    files = mwhatinfile(path)
    for num, fileordir in enumerate(files):
        if misdir(path + '/' + fileordir):
            dirand = emoji['other'][0].format(
                emoji['dir'].format(f'{fileordir} ' + ('' if len(mwhatinfile(path + '/' + fileordir)) == 0 else '*')))
            if len(files) != num + 1:
                FileArchitecture.append(emoji['other'][2].format(dirand))
            else:
                FileArchitecture.append(emoji['other'][1].format(dirand))
        elif misfile(path + '/' + fileordir):
            filep = emoji['other'][0].format(emoji['file'].format(fileordir))
            if len(files) != num + 1:
                FileArchitecture.append(emoji['other'][2].format(filep))
            else:
                FileArchitecture.append(emoji['other'][1].format(filep))
    return FileArchitecture


def reloadplugins():
    pluginsnow = []
    for plugin in mwhatinfile('pkg/ide/plugins'):
        if misfile(f'pkg/ide/plugins/{plugin}/{plugin}.py'):
            if plugin not in ListLoadPlugins:
                ListLoadPlugins.append(plugin)
            pluginsnow.append(plugin)

    for num, i in enumerate(ListLoadPlugins):
        if i not in pluginsnow:
            del ListLoadPlugins[num]


if __name__ == '__main__':
    args = argv[1:]

    if args[0] == '-info':
        print(f'[{prefix}] - {doc}')
    elif args[0] == '-launch':

        setup()
        while True:
            mcls()
            print(loadspeck['Menu']["helpCommand"])
            print('\n'.join(lsfileandemoji()))
            print()

            command = input(f'[{prefix}] -> ').split(' ')
            comadname = command[0]
            comadargs = command[1:]

            if comadname in ListLoadPlugins:
                # Edit python on the python3
                try:
                    reloadplugins()
                    msystem(f'{python_prefix} pkg/ide/plugins/{comadname}/{comadname}.py {path}/ {" ".join(comadargs)}')
                except KeyboardInterrupt:
                    pass

            elif comadname == 'exit':
                print(f'exit {prefix}')
                break

            elif comadname == 'cd':
                try:
                    if comadargs != []:
                        if misdir(f'pkgcache/ide/projects/{minedirpath}'):
                            if comadargs[0] == '..':
                                path = f"pkgcache/ide/projects/{minedirpath}"
                            elif comadargs[0] == '.':
                                if path != f'pkgcache/ide/projects/{minedirpath}':
                                    pp = path.split('/')
                                    path = '/'.join(pp[:-1])
                            else:
                                if misdir(path + '/' + comadargs[0]):
                                    if comadargs[0][0] == '.':
                                        lis = (comadargs[0].split('/'))
                                        del lis[0]
                                        comadargs[0] = '/'.join(lis)
                                    path = path + '/' + ('/'.join(comadargs[0].split('/')))
                                else:
                                    print(loadspeck['CD']['CDError'].format(comadargs[0]))
                                    input(loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass

            elif comadname == 'mkfile':
                try:
                    if comadargs != []:
                        if not misfile(path + '/' + comadargs[0]):
                            open(path + '/' + comadargs[0], 'w')
                        else:
                            while True:
                                num = input(loadspeck['MkFile']['RecreateFile'])
                                if num == 'y' or num == 'n':
                                    break
                            if num == 'y':
                                open(path + '/' + comadargs[0], 'w')
                    else:
                        pathfile = input(loadspeck['MkFile']['MenuCreate'])
                        if not misfile(path + '/' + pathfile):
                            open(path + '/' + pathfile, 'w')
                        else:
                            while True:
                                num = input(loadspeck['MkFile']['RecreateFile'])
                                if num == 'y' or num == 'n':
                                    break
                            if num == 'y':
                                open(path + '/' + pathfile, 'w')
                except KeyboardInterrupt:
                    pass

            elif comadname == 'rm':
                if comadargs != []:
                    num = ''
                    while (False if num == 'y' or num == 'n' else True):
                        num = input(loadspeck['DeleteFile'])
                    if num == 'y':
                        if misfile(path + f'/{comadargs[0]}'):
                            os.remove(path + f'/{comadargs[0]}')
                        elif misdir(path + f'/{comadargs[0]}'):
                            shutil.rmtree(path + f'/{comadargs[0]}')
                else:
                    pathfile = input(loadspeck['MenuDelete'])
                    if mexists(pathfile):
                        num = ''
                        while (False if num == 'y' or num == 'n' else True):
                            num = input(loadspeck['DeleteFile'])
                        if num == 'y':
                            if misfile(path + f'/{comadargs[0]}'):
                                os.remove(path + f'/{comadargs[0]}')
                            elif misdir(path + f'/{comadargs[0]}'):
                                shutil.rmtree(path + f'/{comadargs[0]}')

            elif comadname == 'mv':
                try:
                    if comadargs != []:
                        if len(comadargs) == 2:
                            if misfile(path + f'/{comadargs[0]}') and misdir(path + f'/{comadargs[1]}'):
                                shutil.move(path + f'/{comadargs[0]}', path + f'/{comadargs[1]}')
                            else:
                                print(loadspeck['MV']['MVErrorArgs'])
                                input(loadspeck['EnterPrees'])
                        else:
                            print(loadspeck['MV']['MVErrorPath'])
                            input(loadspeck['EnterPrees'])
                    else:
                        oldfile = input(loadspeck['MV']['MVMenuFile'])
                        newfile = input(loadspeck['MV']['MVMenuDir'])
                        if misfile(path + f'/{oldfile}') and misdir(path + f'/{newfile}'):
                            shutil.move(path + f'/{oldfile}', path + f'/{newfile}')
                        else:
                            print(loadspeck['MV']['MVErrorArgs'])
                            input(loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass

            elif comadname == 'cp':
                try:
                    if comadargs != []:
                        if len(comadargs) == 2:
                            if misfile(path + f'/{comadargs[0]}'):
                                shutil.copy(path + f'/{comadargs[0]}', path + f'/{comadargs[1]}')
                            elif misdir(path + f'/{comadargs[0]}'):
                                shutil.copytree(path + f'/{comadargs[0]}', path + f'/{comadargs[1]}')
                        else:
                            print(loadspeck['CP']['CPErrorOldtoNew'])
                            input(loadspeck['EnterPrees'])

                    else:
                        oldfile = input(loadspeck['CP']['CPMenuOldFile'])
                        newfile = input(loadspeck['CP']['CPMenuNewFile'])
                        if misfile(path + f'/{oldfile}'):
                            shutil.copy(path + f'/{oldfile}', path + f'/{newfile}')
                        elif misdir(path + f'/{oldfile}'):
                            shutil.copytree(path + f'/{oldfile}', path + f'/{newfile}')
                        else:
                            print(loadspeck['CP']['CPMenuPathError'].format(oldfile, newfile))
                            input(loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass

            elif comadname == 'rename':
                try:
                    if comadargs != []:
                        if len(comadargs) == 2:
                            if mexists(path + f'/{comadargs[0]}'):
                                os.rename(path + f'/{comadargs[0]}', path + f'/{comadargs[1]}')
                        else:
                            print(loadspeck['ReName']['ReNameErrorOldtoNew'])
                            input(loadspeck['EnterPrees'])
                    else:
                        oldfile = input(loadspeck['ReName']['ReNameMenuOldFile'])
                        newfile = input(loadspeck['ReName']['ReNameMenuNewFile'])
                        if mexists(path + f'/{oldfile}'):
                            os.rename(path + f'/{oldfile}', path + f'/{newfile}')
                        else:
                            print(loadspeck['ReName']['ReNameMenuErrorPath'].format(oldfile))
                            input(loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass

            elif comadname == 'mkdir':
                try:
                    if comadargs != []:
                        try:
                            if comadargs[0].find('/') == -1:
                                os.mkdir(path + '/' + comadargs[0])
                            else:
                                path_to_file = comadargs[0].split('/')[:-1]
                                if not misdir('/'.join(path_to_file)):
                                    os.mkdir(path + '/' + comadargs[0])
                        except FileNotFoundError:
                            print(loadspeck['MkDir']['MkDirError'])
                            input(loadspeck['EnterPrees'])
                    else:
                        pathfile = input(loadspeck['MkDir']['MkDirDirNamePath'])
                        path_to_file = pathfile.split('/')[:-1]
                        if path_to_file != []:
                            if not misdir(path + '/' + path_to_file):
                                os.mkdir(path + '/' + pathfile)
                            else:
                                print(loadspeck['MkDir']['MkDirDirNameError'])
                                input(loadspeck['EnterPrees'])
                        else:
                            if not misdir(path + '/' + path_to_file):
                                os.mkdir(path + '/' + pathfile)
                except FileExistsError:
                    print(loadspeck['MkDir']['MkDirFileExistsError'])
                    input(loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass
                else:
                    print(loadspeck['MkDir']['MkDirFileCreate'])

            elif comadname == 'help':
                mcls()
                print(loadspeck['IDEHelp']['idehelpmessage'])
                for plug in ListLoadPlugins:
                    msystem(f'{python_prefix} pkg/ide/plugins/{plug}/{plug}.py {path} --info')
                print(loadspeck['IDEHelp']['idehelpstop'])
                input(loadspeck['EnterPrees'])

            elif comadname == 'newdirectory':
                mcls()
                setup()
