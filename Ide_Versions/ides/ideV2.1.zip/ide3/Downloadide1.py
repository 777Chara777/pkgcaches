import sys
import requests
import zipfile
import os
import shutil

import time

"""

Instructions_for_Using_the_System

"""

python_prefix = 'python3'

def __cls_or_clear_platform():
    if "win32" == sys.platform:
        return "cls"
    return "clear"

mwhatinfilepy = lambda path: [(x[:-3] if x.endswith('.py') else None) for x in os.listdir(path)]
mwhatinfile = lambda path: os.listdir(path)
mcls = lambda: os.system(__cls_or_clear_platform())
misfile = lambda path: os.path.isfile(path)
misdir = lambda path: os.path.isdir(path)


if __name__ == '__main__':
    url = 'https://github.com/777Chara777/pkgcaches/raw/main/Ide_Versions/ides/{0}.zip'
    args = sys.argv[1:]

    if len(args) != 0:
        if args[0] != '' and args[1] == '155432':
            if len(args) == 3:
                if args[2] == '-test':
                    time.sleep(5)
                    os.system('start')
            else:
                # os.system('start pause')
                date = requests.get(url.format(args[0]))
                shutil.rmtree('pkg/ide')
                open(f"pkg/ide.zip", 'wb').write(date.content)

                fantasy_zip = zipfile.ZipFile(f'pkg/ide.zip')
                fantasy_zip.extractall('pkg/')

                fantasy_zip.close()

                os.remove(f'pkg/{args[0]}.zip')

