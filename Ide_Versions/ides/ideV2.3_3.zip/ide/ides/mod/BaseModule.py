"""
BaseModule
 - version 1.1 Circumcision version
 - by *-chara-*#7034
"""

import sys
import os

import json
import yaml 

import requests


def __cls_or_clear_platform():
    if sys.platform == 'win32':
        return "cls"
    else:
        return "clear"

def dateurl(url: str) -> dict:
    return json.loads(requests.get(f"{url}", allow_redirects=True).text)

mcls = lambda: os.system(__cls_or_clear_platform())
mplatform = lambda: sys.platform
misfile = lambda path: os.path.isfile(path)
misdir = lambda path: os.path.isdir(path)
mkdir = lambda path: os.mkdir(path)
mexists = lambda path: os.path.exists(path)
mwhatinfile = lambda path: os.listdir(path)
msystem = lambda command: os.system(command)

mconfigide = lambda : loadall_json('pkgcache/ide/settings_ide.json')

def load_json(derictory, Name, Name2=None):
    try:
        with open(derictory, encoding="utf-8") as config_file:
            data = json.load(config_file)
            config_file.close()
        Num = data[str(Name)]
        if Name2 != None:
            Num2 = data[str(Name2)]
        else:
            return "!", Num, None
        return "!", Num, Num2
    except:
        return None, None, None


def input_json(derictory, Data):
    with open(derictory, 'w', encoding="utf-8") as file:
        json.dump(Data, file, indent=2, ensure_ascii=False)


def loadall_json(derictory) -> 'dict | None':
    if misfile(derictory):
        with open(derictory, encoding="utf-8") as config_file:
            data = json.load(config_file)
        return data
    else:
        return None

def input_yaml(derictory, Data):
    with open(derictory, 'w', encoding="utf-8") as file:
        yaml.dump(Data, stream=file, default_flow_style=False, sort_keys=False)

def loadall_yaml(derictory) -> 'yaml | None':
    if misfile(derictory):
        with open(derictory, encoding="utf-8") as config_file:
            return yaml.load(config_file, Loader=yaml.FullLoader)
    else:
        return None