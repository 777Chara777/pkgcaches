try:
    from ides.mod.BaseModule import *
except:
    from mod.BaseModule import *
    
class speck:
    def __init__(self, file):
        self.file = file
        self.idelangfile: dict = loadall_json('pkg/ide/lang/langs.json')
        self.speck = None
    
    def loadlang(self) -> dict:
        with open(".lset", encoding='utf-8') as f:
            self.speck = self.idelangfile[self.file][1][f.readline()]
        return self.speck 

    def specktest(self, date:dict) -> dict:
        with open(".lset") as f:
            return date[f.readline()]