import os
import shutil

from sys import argv

from mod.LangModule import *
from mod.BaseModule import *


class IDE:
    def __init__(self) -> None:
        self.loadspeck = speck('$IDE_V1.2a').loadlang()
        self.IDeVersion = '1.2a'
        self.doc = self.loadspeck['Documentation']
        self.prefix = f'IDEv{self.IDeVersion}'
        self.python_prefix = mconfigide()['Python']

        self.rootdir = None
        self.rootpath = 'pkgcache/ide/projects'

        self.emoji = {
            'dir': '📁 {0}',
            'opendir': '🗃️  {0}',
            'dirhavefile': '🗂️  {0}',
            'view': "🔍 {0}",
            'rename': '📝  {0}',
            'edit': '✏️  {0}',
            'install': '📦 {0}',
            'cd': '⤵️  {0}',
            'exit': '❌ {0}',
            'runer': '🏃 {0}',
            'delete': '🗑️  {0}',
            'copy': '📑 {0}',
            'move': '🧳 {0}',
            'file': '📄 {0}',
            'other': [
                '─{0}', 
                '└{0}', 
                '├{0}',
                ' {0}'
            ]
        }
        self.ListLoadPlugins = []
        for plugin in mwhatinfile('pkg/ide/plugins'):
            if misfile(f'pkg/ide/plugins/{plugin}/{plugin}.py'):
                self.ListLoadPlugins.append(plugin)

    def setup(self):
        if not misdir("pkgcache/ide"):
            exit()
        
        if not misdir("pkgcache/ide/projects"):
            mkdir("pkgcache/ide/projects")
        a: str = '' if len(mwhatinfile('pkgcache/ide/projects')) != 0 else 'c'
        if a == '':
            while True:
                a = input(self.loadspeck['setup']['ProjectCreateorOpen'].format(self.prefix))
                if a == 'o' or a == 'c':
                    break
        if a == 'o':
            dirinfo = mwhatinfile('pkgcache/ide/projects/')
            print()
            for i in range(len(dirinfo)):
                print(f"{i}) {self.emoji['dir'].format(dirinfo[i])}")
            print()
            while True:
                num = input(self.loadspeck['setup']['OpenFile'].format(self.prefix))
                try:
                    int(num)
                except ValueError:
                    pass
                else:
                    if len(dirinfo) < int(num):
                        print(self.loadspeck['setup']['ErrorNotFindNumber'].format(self.prefix, num))
                        input(self.loadspeck['EnterPrees'])
                    else:
                        nd = dirinfo[int(num)]
                        break
        elif a == 'c':
            versionprogect: str = ''
            while True:
                n = input(self.loadspeck['setup']['HackOSPackageorProject'].format(self.prefix))
                if n == '1' or n == '2':
                    break
            if n == '1':
                versionprogect = input(self.loadspeck['setup']['HackOSPackageVersion'].format(self.prefix))
            while True:
                nd = versionprogect + input(self.loadspeck['setup']['CreateFile'].format(self.prefix))
                if not misdir(f'pkgcache/ide/projects/{nd}'):
                    mkdir(f'pkgcache/ide/projects/{nd}')
                    if n == '1':
                        open(f'pkgcache/ide/projects/{nd}/install', 'w')
                        open(f'pkgcache/ide/projects/{nd}/main.py', 'w')
                    break
                else:
                    print(self.loadspeck['setup']['ErrorIsFile'].format(self.prefix))
        self.rootdir = nd
        self.rootpath = f"pkgcache/ide/projects/{nd}"

    def lsfileandemoji(self):
        FileArchitecture = [f'{self.emoji["opendir"].format("/".join(self.rootpath.split("/")[3:]))}']
        files = mwhatinfile(self.rootpath+'/')
        for num, fileordir in enumerate(files):
            if misdir(self.rootpath+'/'+fileordir):
                dirand = self.emoji['other'][0].format(self.emoji['dir' if len(mwhatinfile(self.rootpath+'/'+fileordir)) == 0 else 'dirhavefile'].format(f'{fileordir} '+ ('' if len(mwhatinfile(self.rootpath+'/'+fileordir)) == 0 else '*')))
                # dirhavefile dir
                if len(files) != num+1:
                    FileArchitecture.append(self.emoji['other'][2].format(dirand))
                else:
                    FileArchitecture.append(self.emoji['other'][1].format(dirand))        
            elif misfile(self.rootpath+'/'+fileordir):
                filep = self.emoji['other'][0].format(self.emoji['file'].format(fileordir))
                if len(files) != num+1:
                    FileArchitecture.append(self.emoji['other'][2].format(filep))
                else:
                    FileArchitecture.append(self.emoji['other'][1].format(filep))
        return FileArchitecture

    def Notfile(self):
        if len(mwhatinfile(f'{self.rootpath}')) == 0:
            print(self.loadspeck['NotFile']['HelpMessage'].format(self.emoji["dir"].format("Create Dir"),self.emoji["file"].format("Create File"),self.emoji["cd"].format("Cd")))

    def CreateDir(self):
        try:
            pathfile = input(self.loadspeck['CreateDir']['dirname']) 
            if not misdir(self.rootpath+'/'+pathfile):
                os.mkdir(self.rootpath+'/'+pathfile)
            else:
                print(self.loadspeck['CreateDir']['didetect'].format(pathfile))
                input(self.loadspeck['EnterPrees'])
        except KeyboardInterrupt:
            pass

    def CreateFile(self):
        try:
            pathfile = input(self.loadspeck['CreateFile']['filename'])
            if not misfile(self.rootpath+'/'+pathfile):
                open(self.rootpath+'/'+pathfile, 'w')
            else:
                while True:
                    num = input(self.loadspeck['CreateFile']['fileyesorno'])
                    if num == 'y' or num == 'n':
                        break
                if num == 'y':
                    open(self.rootpath+'/'+pathfile, 'w') 
        except KeyboardInterrupt:
            pass

    def cdwe(self, commands: str):
        try:
            if commands == '..':
                self.setup()
            elif commands == '.':
                if self.rootpath != f'pkgcache/ide/projects/{self.rootdir}':
                    pp = self.rootpath.split('/')
                    self.rootpath = '/'.join(pp[:-1])
            else:
                if misdir(self.rootpath+f'/{commands}'):
                    self.rootpath = self.rootpath+f'/{commands}'
                else:
                    print(self.loadspeck['cdwe']['cdErrorpath'].format(commands))
                    input()
        except KeyboardInterrupt:
            pass

    def reloadpluagins(self):
        pluginsnow = []
        for plugin in mwhatinfile('pkg/ide/plugins'):
            if plugin not in self.ListLoadPlugins:
                self.ListLoadPlugins.append(plugin)
            pluginsnow.append(plugin)
        
        for num, i in enumerate(self.ListLoadPlugins):
            if i not in pluginsnow:
                del self.ListLoadPlugins[num]

    def Run(self):
        args = argv[1:]
        if args[0] == '-info':
            print(f'[{self.prefix}] - {self.doc}')
        elif args[0] == '-launch':

            self.setup()
            while True:    
                mcls()
                print('\n'.join(self.lsfileandemoji()))
                self.Notfile()
                print()
                command = input(f'[{self.prefix}] >>> ')
                self.commands(command)


    def commands(self, command: str):
        if mexists(self.rootpath+f'/{command}') and command != '.' and command.replace(' ','') != '':
            fileordir = command
            filedol = "file" if misfile(self.rootpath+f"/{command}") else "dir"
            command_num = None
            while True:
                mcls()
                if filedol == 'file':
                    print(self.loadspeck['Menu']['PrintFileHelp'].format((self.emoji["delete"].format("Delete")),(self.emoji["edit"].format("Rename")),(self.emoji["copy"].format("Copy")),(self.emoji["move"].format("Move")),(self.emoji["edit"].format("Edit")),(self.emoji["runer"].format("Run File")),(self.emoji['install'].format("Install")),(self.emoji['view'].format("View")),(self.emoji["exit"].format("Exit"))))
                
                elif filedol == 'dir':
                    print(self.loadspeck['Menu']['PrintDirHelp'].format(self.emoji["delete"].format("Delete"),self.emoji["edit"].format("Rename"),self.emoji["copy"].format("Copy"),self.emoji["move"].format("Move"),self.emoji["cd"].format("Cd"),self.emoji["exit"].format("Exit")))
                
                commad = input(f'[{self.prefix}] {self.emoji[filedol].format(fileordir)} -> ')
                try:
                    int(commad)
                except ValueError:
                    pass
                else:
                    if filedol == 'dir' and int(commad) == 5:
                        exit()
                    elif filedol == 'file' and int(commad) == 8:
                        exit()

                    elif int(commad) <= 7: 
                        command_num = int(commad)
                        break
            if command_num == 0:
                try:
                    num = ''
                    while (False if num == 'y' or num == 'n' else True):
                        num = input(self.loadspeck['Menu']['RemoveFile'])
                    if num == 'y':
                        if filedol == 'file':
                            os.remove(self.rootpath+f'/{fileordir}')
                        elif filedol == 'dir':
                            shutil.rmtree(self.rootpath+f'/{fileordir}')
                except KeyboardInterrupt:
                    pass

            elif command_num == 1:
                try:
                    while True:
                        filename = input(self.loadspeck['Menu']['ReName'])
                        if not mexists(self.rootpath+f'/{filename}'):
                            break
                    os.rename(self.rootpath+f'/{command}', self.rootpath+f'/{filename}')
                except KeyboardInterrupt:
                    pass
        
            elif command_num == 2:
                newfile = input(self.loadspeck['Menu']['CopyFile'])
                if misfile(self.rootpath+f'/{fileordir}'):
                    shutil.copy(self.rootpath+f'/{fileordir}', self.rootpath+f'/{newfile}')
                elif misdir(self.rootpath+f'/{fileordir}'):
                    shutil.copytree(self.rootpath+f'/{fileordir}', self.rootpath+f'/{newfile}')
                else:
                    print(self.loadspeck['Menu']['CopyFile'].format(newfile))
                    input(self.loadspeck['EnterPrees'])

            elif command_num == 3:
                newfile = input(self.loadspeck['Menu']['MoveFile'])
                if misdir(self.rootpath+f'/{newfile}'):
                    shutil.move(self.rootpath+f'/{fileordir}', self.rootpath+f'/{newfile}')
                else:
                    print(self.loadspeck['Menu']['MoveFileError'])
                    input(self.loadspeck['EnterPrees'])

            elif command_num == 4:
                if filedol == 'file':
                    try:
                        self.reloadpluagins()
                        if 'edit' in self.ListLoadPlugins:
                            msystem(f'{self.python_prefix} pkg/ide/plugins/edit/edit.py {self.rootpath}/ {fileordir}')
                        else:
                            print(self.loadspeck['Menu']["editPluginError"].format(self.prefix))
                            input(self.loadspeck['EnterPrees'])
                    except KeyboardInterrupt:
                        pass
                elif filedol == 'dir':
                    self.cdwe(fileordir)
            
            elif command_num == 5:
                try:
                    self.reloadpluagins()
                    if 'run' in self.ListLoadPlugins:
                        msystem(f'{self.python_prefix} pkg/ide/plugins/run/run.py {self.rootpath}/ {fileordir}')
                    else:
                        print(self.loadspeck['Menu']['runPluginError'].format(self.prefix))
                        input(self.loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass

            elif command_num == 6 and filedol == 'file':
                try:
                    self.reloadpluagins()
                    pathandfileordir = self.rootpath+'/'+fileordir
                    if pathandfileordir.split('/')[-1] in ['install','install.sh'] and 'install' in self.ListLoadPlugins:
                        if pathandfileordir.split('/')[-1] == 'install.sh':
                            oneline = open(f'{pathandfileordir}', 'r').readlines(0)
                            if str(oneline[0]).split()[0] in ['pip', 'pip3']:
                                for line in open(f'{pathandfileordir}', 'r').readlines():
                                    msystem(line.replace('\n', ''))
                            else:
                                for line in open(f'{pathandfileordir}', 'r').readlines():
                                    msystem(f'{self.python_prefix} pkg/ide/plugins/install/install.py '+ line.replace("\n", ""))
                                    input()
                        else:
                            for line in open(f'{pathandfileordir}', 'r').readlines():
                                print('3', line.replace('\n', ''))
                                msystem(f'{self.python_prefix} pkg/ide/plugins/install/install.py '+ line.replace("\n", ""))
                    else:
                        if 'install' in self.ListLoadPlugins:
                            print(self.loadspeck['Install']['Messagepip'])
                            installfiles = input(self.loadspeck['Install']['Inputipip'])
                            msystem(f'{self.python_prefix} pkg/ide/plugins/install/install.py {installfiles}')
                        else:
                            print(self.loadspeck['Menu']['installPluginError'].format(self.prefix))
                            input(self.loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass
            elif command_num == 7 and filedol == 'file':
                try:
                    self.reloadpluagins()
                    if 'view' in self.ListLoadPlugins:
                        msystem(f'{self.python_prefix} pkg/ide/plugins/view/view.py {self.rootpath}/ {fileordir}')
                    else:
                        print(self.loadspeck['Menu']['viewPluginError'].format(self.prefix))
                        input(self.loadspeck['EnterPrees'])
                except KeyboardInterrupt:
                    pass
            
        elif command.strip() == 'exit':
            print(f'exit {self.prefix}')
            exit()

        elif command.replace(' ', '') == '':
            pass
        
        elif command == '0':
            self.CreateDir()
        elif command == '1':
            self.CreateFile()
        elif command == '2':
            if self.rootpath.split('/')[-1] == self.rootdir:
                mcls()
                self.cdwe('..')
            else:
                self.cdwe('.')

        else:
            print(self.loadspeck['Menu']['ErrorPath'].format(self.prefix,command))
            input(self.loadspeck['EnterPrees'])

if __name__ == '__main__': 
    ide = IDE()
    ide.Run()
    