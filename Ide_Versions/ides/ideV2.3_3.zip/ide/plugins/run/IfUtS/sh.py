import sys
import os

msystem = lambda comm : os.system(comm)
misdir = lambda path : os.path.isdir(path)
if __name__ == '__main__':
    args = sys.argv[1:]
    
    if args[1] == '-comp':
        print(f'{args[2]} Sh')

    elif len(args) != 0:
        try:
            msystem(f'{args[1]}')
        except KeyboardInterrupt:
            pass
    