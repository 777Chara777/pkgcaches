from CheckVersion import *
from ides.mod.BaseModule import *
from ides.mod.LangModule import *

"""
Main File Wow
 - version 2.3 Circumcision version
 - by *-chara-*#7034
"""

class MainLauncher:
    def __init__(self) -> None:
        self.setup()
        self.loadspeck = speck('$__main__.py').loadlang()
        self.settings = mconfigide
        self.Vlaunch: str = 'V2.3_3'
        self.checkup = CheckVersion(self.Vlaunch)
        self.Idlaunch: int = self.checkup.CheckVersion()

        self.date = {'NumLauncher': self.Idlaunch,
                    'NameLauncher': self.Vlaunch,
                    'Python': 'python3',
                    'IdeType': None}

        if self.settings() == None:
            self.CreateStartConfig()
        elif self.settings().get('NameLauncher') != None and self.settings()['NameLauncher'] != self.Vlaunch:
            input_json('pkgcache/ide/settings_ide.json', {})
            self.CreateStartConfig()
        elif self.settings().get('NameLauncher') == None:
            self.CreateStartConfig()
        
    def setup(self):
        if not misdir('pkgcache/ide'):
            mkdir('pkgcache/ide')

        self.ideload = []
        num = 0
        for files in mwhatinfile('pkg/ide/ides/'):
            if str(files).endswith('.py') and files.find('ide_') != -1:
                self.ideload.append([files[:-3], files, num])
                num+=1
        del num

    def CreateStartConfig(self):
        print(f'IDE {self.Vlaunch}-{self.Idlaunch}')

        print(str(self.loadspeck['SettingsIDE']['Welcom']).format(" , ".join([f'{x[2]}) {x[0]}' for x in self.ideload])))
        for ide in self.ideload:
            msystem(f"{self.date['Python']} pkg/ide/ides/{ide[1]} -info")
        print()
        print(str(self.loadspeck['SettingsIDE']['IDE!']))

        while True:
            num = input('Num - IDE Version: ')
            try:
                int(num)
            except ValueError:
                pass
            else:
                if int(num) in [x[2] for x in self.ideload]:
                    self.date['IdeType'] = self.ideload[int(num)][1]
                    break
        
        input_json('pkgcache/ide/settings_ide.json', self.date)
        
    def Run(self):
        while True:
            if misfile('pkgcache/ide/set') != True:
                open("pkgcache/ide/set", "w").close()
            temp = open("pkgcache/ide/set", "r+")
            ii = bool(temp.read())

            if ii:
                if self.settings()['IdeType'] in [x[1] for x in self.ideload]:
                    msystem(f"{self.settings()['Python']} pkg/ide/ides/{self.settings()['IdeType']} -launch")
                break
            else:
                a: str = ""
                while False if a == 'y' or a == 'n' else True:
                    a = input(str(self.loadspeck['InstallC'])).lower()
                if a != "n":
                    msystem("apt install gcc")
                    msystem("apt install g++")
                open("pkgcache/ide/set", "w").write(str(True))
                msystem(f"{self.settings()['Python']} pkg/ide/ides/{self.settings()['IdeType']} -launch")
                break

if __name__ == '__main__':
    mcls()
    milaunch = MainLauncher()
    milaunch.Run()
